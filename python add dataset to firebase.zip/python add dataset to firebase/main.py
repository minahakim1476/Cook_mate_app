import firebase_admin
from firebase_admin import credentials, firestore
import pandas as pd

# Load dataset
df = pd.read_csv("recipes.csv", encoding='utf-8')

# Firebase Admin Init
cred = credentials.Certificate("cookmate-b7001-firebase-adminsdk-fbsvc-b1a0f3553a.json")
firebase_admin.initialize_app(cred)
db = firestore.client()
uuid = "A5iXAbBwD2eSS5V68WuDZePVkl12"
# Add rows to Firestore
for index, row in df.iterrows():
    recipe_dict = {
        "uuid": uuid,
        "recipe_name": row["recipe_name"],
        "prep_time": row["prep_time"],
        "cook_time": row["cook_time"],
        "total_time": row["total_time"],
        "servings": row["servings"],
        "yield": row["yield"],
        "ingredients": row["ingredients"],
        "directions": row["directions"],
        "rating": row["rating"],
        "url": row["url"],
        "cuisine_path": row["cuisine_path"],
        "nutrition": row["nutrition"],
        "timing": row["timing"],
        "img_src": row["img_src"]
    }

    # Add to Firestore collection
    doc_ref = db.collection("recipes").document()
    doc_ref.set(recipe_dict)

print("Upload Completed Successfully 🎉")
